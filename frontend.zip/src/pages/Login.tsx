import { AuthForm } from "../components/auth/AuthForm";

export default function Login() {
  return <AuthForm />;
}